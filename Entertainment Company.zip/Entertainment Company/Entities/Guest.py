class Guest:
    def __init__(self, guest_id, name, address, contact_details):
      
        self.guest_id = guest_id
        self.name = name
        self.address = address
        self.contact_details = contact_details
