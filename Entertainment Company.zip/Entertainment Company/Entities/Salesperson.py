class Salesperson:
    def __init__(self, name, employee_id, department, job_title, basic_salary, age, dob, passport_details, sales_targets):
       
        self.name = name
        self.employee_id = employee_id
        self.department = department
        self.job_title = job_title
        self.basic_salary = basic_salary
        self.age = age
        self.dob = dob
        self.passport_details = passport_details
        self.sales_targets = sales_targets
