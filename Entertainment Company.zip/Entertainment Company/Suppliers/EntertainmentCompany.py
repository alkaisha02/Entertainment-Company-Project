class EntertainmentCompany:
    def __init__(self, supplier_id, name, address, contact_details, entertainment_type, services_offered):
     
        self.supplier_id = supplier_id
        self.name = name
        self.address = address
        self.contact_details = contact_details
        self.entertainment_type = entertainment_type
        self.services_offered = services_offered
    