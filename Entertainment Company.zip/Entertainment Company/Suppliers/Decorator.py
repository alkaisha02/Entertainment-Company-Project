class Decorator:
    def __init__(self, supplier_id, name, address, contact_details, decoration_theme, decoration_style):
       
        self.supplier_id = supplier_id
        self.name = name
        self.address = address
        self.contact_details = contact_details
        self.decoration_theme = decoration_theme
        self.decoration_style = decoration_style
